TEMPLATE BUKU TA VERSI 2.0

Disusun tanggal 28 Agustus 2026.

Disclaimer:  Template ini disusun dari template sebelumnya (TEMPLATE BUKU TA VERSI 1.0) yang disusun oleh Cica Gustiani (TF-ITB 2007) dan Laurenzius Yudha Prasetya Tama (FI-ITB 2017).

Editor saat ini: Yusuf Naufal (TF-ITERA 2021)
****************************************************************************************************************************************************

Beberapa catatan:
1. Template versi 2.0 ini disesuaikan dengan pedoman buku tugas akhir Teknik Fisika Institut Teknologi Sumatera.
2. Template ini dapat di-compile melalu overleaf.com, prism.openai.com, dan vs-code terintegrasi Mik-Tex. Untuk alasan kemudahan, disarankan template buku TA ini di-compile melalui situs overleaf.com.
3. Template versi 2.0 dapat diakses melalui url: (https://github.com/yn-go/Latex-Template-Buku_TA-TF_ITERA)